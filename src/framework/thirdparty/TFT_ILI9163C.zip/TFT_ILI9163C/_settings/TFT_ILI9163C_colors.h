#ifndef _TFT_ILI9163C_COLORS_H_
#define _TFT_ILI9163C_COLORS_H_


#define	BLACK   	0x0000
#define WHITE   	0xFFFF
#define BLUE    	0x001F
#define RED     	0xF800
#define GREEN   	0x07E0
#define CYAN    	0x07FF
#define MAGENTA 	0xF81F
#define YELLOW  	0xFFE0
//added
#define BRIGHT_RED	0xF810	
#define LIGHT_GREY	0x8410  
#define DARK_GREY	0x4208  
#endif
